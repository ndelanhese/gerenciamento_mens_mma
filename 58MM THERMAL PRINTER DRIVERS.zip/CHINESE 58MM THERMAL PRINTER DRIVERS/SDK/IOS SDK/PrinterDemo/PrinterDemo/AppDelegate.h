//
//  AppDelegate.h
//  ZiJiangPrinterDemo
//
//  Created by aduo on 5/30/16.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

