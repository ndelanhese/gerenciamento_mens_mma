//
//  CollectionViewDemoController.h
//  IQKeyboard
//
//  Created by Iftekhar on 29/10/14.
//  Copyright (c) 2014 Iftekhar. All rights reserved.
//

#import <UIKit/UIKit.h>

#ifdef NSFoundationVersionNumber_iOS_5_1

@interface CollectionViewDemoController : UIViewController

@end

#endif