//
//  ViewController.h
//  ZiJiangPrinterDemo
//
//  Created by aduo on 5/30/16.
//
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

